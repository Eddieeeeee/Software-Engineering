﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Add_Expenses : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\USER\documents\visual studio 2015\Projects\WindowsFormsApplication1\WindowsFormsApplication1\Church Database.mdf;Integrated Security=True;Connect Timeout=30");

        public Add_Expenses()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {




            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO   [Expense] values ('" + transc_id.Text + "', '" + pto.Text + "','" + pdescription.Text + "','" + cmboCategory.SelectedValue + "','" + cmboAccount.SelectedValue + "','" +
               amount.Text + "')";

              

                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("The data is recorded has been inserted");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }





        }

        private void pdescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void Add_Expenses_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'church_DatabaseDataSet.Expense' table. You can move, or remove it, as needed.
            this.expenseTableAdapter.Fill(this.church_DatabaseDataSet.Expense);
           
        }

     
       

        private void pto_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

}



