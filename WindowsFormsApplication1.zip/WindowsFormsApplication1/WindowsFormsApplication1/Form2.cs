﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C: \Users\USER\documents\visual studio 2015\Projects\WindowsFormsApplication1\WindowsFormsApplication1\Church Database.mdf;Integrated Security=True;Connect Timeout=30");

        public Form2()
        {
            InitializeComponent();
        }

       

        private void Form2_Load(object sender, EventArgs e)
        {


            chartIncomeAnalysis.Series["AnalysisIncome"].Points.Add(1000);
            chartIncomeAnalysis.Series["AnalysisIncome"].Points.Add(2);
            chartIncomeAnalysis.Series["AnalysisIncome"].Points.Add(12);
            chartIncomeAnalysis.Series["AnalysisIncome"].Points.Add(12);

            chartExpenseAnalysis.Series["AnalysisExpense"].Points.Add(12);
            chartExpenseAnalysis.Series["AnalysisExpense"].Points.Add(12);
            chartExpenseAnalysis.Series["AnalysisExpense"].Points.Add(12);
            chartExpenseAnalysis.Series["AnalysisExpense"].Points.Add(12);






            // TODO: This line of code loads data into the 'church_DatabaseDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.church_DatabaseDataSet.Table);
            // TODO: This line of code loads data into the 'church_DatabaseDataSet.Expense' table. You can move, or remove it, as needed.
            this.expenseTableAdapter.Fill(this.church_DatabaseDataSet.Expense);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void incomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 ss = new Form3();
            ss.Show();
        }

        private void expenditureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 ss = new Form4();
            ss.Show();

        }

        private void financialGrowthToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnFinancials_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
             AddIncome  frm2 = new AddIncome (this);
            frm2.Show();


        }

        private void button3_Click(object sender, EventArgs e)
        {
           Add_Expenses  frm2 = new Add_Expenses();
            frm2.Show();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            int a, b, c, d, f;

            a = Convert.ToInt32(male_fservice.Text);
            b = Convert.ToInt32(female_fservice .Text);
            c = Convert.ToInt32(male_secservice.Text);
            d = Convert.ToInt32(female_secservice.Text);
            f = a + b + c + d;

            total.Text = f.ToString();

            try
            {

                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into Attendance values ('" + male_fservice.Text + "', '" + female_fservice.Text + "','" + male_secservice.Text + "','" + female_secservice.Text + "','" + total.Text + "','" + submittedby.Text + "')";

                cmd.ExecuteNonQuery();
                con.Close();

             


            }
            catch (Exception)
            {
                MessageBox.Show("The data is recorded has been inserted");
            }

        
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void chartIncome_Click(object sender, EventArgs e)
        {

        }

       

        private void button5_Click(object sender, EventArgs e)
        {

            using (Church_DatabaseDataSet db = new Church_DatabaseDataSet())
            {
                chartIncome.DataSource = db.Table.ToList();


                chartIncome.Series["Income"].XValueMember = "amount";
                chartIncome.Series["Income"].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;


                chartExpense.DataSource = db.Expense.ToList();
                chartExpense.Series["Expense"].YValueMembers = "amount";
                chartExpense.Series["Expense"].YValueType
 = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;

               
                 }
        }

        private void chartAnalysis_Click(object sender, EventArgs e)
        {

        }

        private void chartExpense_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Income_Report frm2 = new Income_Report();
            frm2.Show();

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Expense_Report frm2 = new Expense_Report();
            frm2.Show();


        }
    }
}
