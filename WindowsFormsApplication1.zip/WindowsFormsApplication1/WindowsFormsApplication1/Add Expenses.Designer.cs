﻿namespace WindowsFormsApplication1
{
    partial class Add_Expenses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button2 = new System.Windows.Forms.Button();
            this.amount = new System.Windows.Forms.TextBox();
            this.expenseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.church_DatabaseDataSet = new WindowsFormsApplication1.Church_DatabaseDataSet();
            this.transc_id = new System.Windows.Forms.TextBox();
            this.pdescription = new System.Windows.Forms.TextBox();
            this.cmboCategory = new System.Windows.Forms.ComboBox();
            this.cmboAccount = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pto = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.expenseTableAdapter = new WindowsFormsApplication1.Church_DatabaseDataSetTableAdapters.ExpenseTableAdapter();
            this.tableTableAdapter = new WindowsFormsApplication1.Church_DatabaseDataSetTableAdapters.TableTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.expenseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.church_DatabaseDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(335, 367);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(185, 34);
            this.button2.TabIndex = 30;
            this.button2.Text = "Add Expense Transaction ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // amount
            // 
            this.amount.AccessibleName = "";
            this.amount.BackColor = System.Drawing.Color.WhiteSmoke;
            this.amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.amount.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.expenseBindingSource, "amount", true));
            this.amount.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.amount.ForeColor = System.Drawing.Color.Black;
            this.amount.Location = new System.Drawing.Point(285, 260);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(235, 27);
            this.amount.TabIndex = 29;
            this.amount.Text = "000";
            this.amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // expenseBindingSource
            // 
            this.expenseBindingSource.DataMember = "Expense";
            this.expenseBindingSource.DataSource = this.church_DatabaseDataSet;
            // 
            // church_DatabaseDataSet
            // 
            this.church_DatabaseDataSet.DataSetName = "Church_DatabaseDataSet";
            this.church_DatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // transc_id
            // 
            this.transc_id.AccessibleName = "";
            this.transc_id.BackColor = System.Drawing.Color.WhiteSmoke;
            this.transc_id.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.transc_id.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.expenseBindingSource, "transc_id", true));
            this.transc_id.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.transc_id.ForeColor = System.Drawing.Color.DimGray;
            this.transc_id.Location = new System.Drawing.Point(41, 260);
            this.transc_id.Name = "transc_id";
            this.transc_id.Size = new System.Drawing.Size(204, 27);
            this.transc_id.TabIndex = 28;
            this.transc_id.Text = "Transaction ID";
            // 
            // pdescription
            // 
            this.pdescription.AccessibleName = "";
            this.pdescription.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pdescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pdescription.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.expenseBindingSource, "pdescription", true));
            this.pdescription.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.pdescription.ForeColor = System.Drawing.Color.DimGray;
            this.pdescription.Location = new System.Drawing.Point(41, 136);
            this.pdescription.Name = "pdescription";
            this.pdescription.Size = new System.Drawing.Size(295, 27);
            this.pdescription.TabIndex = 27;
            this.pdescription.Text = "Payment Description";
            this.pdescription.TextChanged += new System.EventHandler(this.pdescription_TextChanged);
            // 
            // cmboCategory
            // 
            this.cmboCategory.BackColor = System.Drawing.Color.White;
            this.cmboCategory.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.expenseBindingSource, "category", true));
            this.cmboCategory.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmboCategory.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.cmboCategory.FormattingEnabled = true;
            this.cmboCategory.Items.AddRange(new object[] {
            "Offerings",
            "Tithes",
            "Pleges"});
            this.cmboCategory.Location = new System.Drawing.Point(275, 196);
            this.cmboCategory.Name = "cmboCategory";
            this.cmboCategory.Size = new System.Drawing.Size(196, 23);
            this.cmboCategory.TabIndex = 26;
            this.cmboCategory.Text = "Offerings";
            this.cmboCategory.SelectedIndexChanged += new System.EventHandler(this.cmboCategory_SelectedIndexChanged);
            // 
            // cmboAccount
            // 
            this.cmboAccount.BackColor = System.Drawing.Color.White;
            this.cmboAccount.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.expenseBindingSource, "account", true));
            this.cmboAccount.Font = new System.Drawing.Font("Segoe UI Semibold", 9.25F, System.Drawing.FontStyle.Bold);
            this.cmboAccount.ForeColor = System.Drawing.Color.DarkGray;
            this.cmboAccount.FormattingEnabled = true;
            this.cmboAccount.Items.AddRange(new object[] {
            "All Accounts",
            "Cash"});
            this.cmboAccount.Location = new System.Drawing.Point(41, 196);
            this.cmboAccount.Name = "cmboAccount";
            this.cmboAccount.Size = new System.Drawing.Size(204, 23);
            this.cmboAccount.TabIndex = 25;
            this.cmboAccount.Text = "Cash";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 25);
            this.label1.TabIndex = 24;
            this.label1.Text = "Add Expense";
            // 
            // pto
            // 
            this.pto.AccessibleName = "";
            this.pto.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pto.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.expenseBindingSource, "pto", true));
            this.pto.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.pto.ForeColor = System.Drawing.Color.DimGray;
            this.pto.Location = new System.Drawing.Point(41, 94);
            this.pto.Name = "pto";
            this.pto.Size = new System.Drawing.Size(295, 27);
            this.pto.TabIndex = 23;
            this.pto.Text = "Payment To";
            this.pto.TextChanged += new System.EventHandler(this.pto_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(464, 24);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 31;
            this.button1.Text = "close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // expenseTableAdapter
            // 
            this.expenseTableAdapter.ClearBeforeFill = true;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // Add_Expenses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(561, 428);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.amount);
            this.Controls.Add(this.transc_id);
            this.Controls.Add(this.pdescription);
            this.Controls.Add(this.cmboCategory);
            this.Controls.Add(this.cmboAccount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Expenses";
            this.Text = "Add_Expenses";
            this.Load += new System.EventHandler(this.Add_Expenses_Load);
            ((System.ComponentModel.ISupportInitialize)(this.expenseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.church_DatabaseDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox amount;
        private System.Windows.Forms.TextBox transc_id;
        private System.Windows.Forms.TextBox pdescription;
        private System.Windows.Forms.ComboBox cmboCategory;
        private System.Windows.Forms.ComboBox cmboAccount;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox pto;
        private System.Windows.Forms.Button button1;
        private Church_DatabaseDataSet church_DatabaseDataSet;
        private System.Windows.Forms.BindingSource expenseBindingSource;
        private Church_DatabaseDataSetTableAdapters.ExpenseTableAdapter expenseTableAdapter;
        private Church_DatabaseDataSetTableAdapters.TableTableAdapter tableTableAdapter;
    }
}