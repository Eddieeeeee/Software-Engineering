﻿namespace WindowsFormsApplication1
{
    partial class AddIncome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pfrom = new System.Windows.Forms.TextBox();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.church_DatabaseDataSet = new WindowsFormsApplication1.Church_DatabaseDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.pdescription = new System.Windows.Forms.TextBox();
            this.transc_id = new System.Windows.Forms.TextBox();
            this.amount = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tableTableAdapter = new WindowsFormsApplication1.Church_DatabaseDataSetTableAdapters.TableTableAdapter();
            this.churchDatabaseDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cmboAccount = new System.Windows.Forms.ComboBox();
            this.cmboCategory = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.church_DatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.churchDatabaseDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pfrom
            // 
            this.pfrom.AccessibleName = "";
            this.pfrom.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pfrom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pfrom.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tableBindingSource, "pfrom", true));
            this.pfrom.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.pfrom.ForeColor = System.Drawing.Color.DimGray;
            this.pfrom.Location = new System.Drawing.Point(12, 70);
            this.pfrom.Name = "pfrom";
            this.pfrom.Size = new System.Drawing.Size(295, 27);
            this.pfrom.TabIndex = 15;
            this.pfrom.Text = "Payment From";
            this.pfrom.TextChanged += new System.EventHandler(this.pfrom_TextChanged);
            this.pfrom.Enter += new System.EventHandler(this.pfrom_Enter);
            this.pfrom.Leave += new System.EventHandler(this.pfrom_Leave);
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.church_DatabaseDataSet;
            // 
            // church_DatabaseDataSet
            // 
            this.church_DatabaseDataSet.DataSetName = "Church_DatabaseDataSet";
            this.church_DatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 25);
            this.label1.TabIndex = 16;
            this.label1.Text = "Add Income";
            // 
            // pdescription
            // 
            this.pdescription.AccessibleName = "";
            this.pdescription.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pdescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pdescription.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tableBindingSource, "pdescription", true));
            this.pdescription.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.pdescription.ForeColor = System.Drawing.Color.DimGray;
            this.pdescription.Location = new System.Drawing.Point(12, 112);
            this.pdescription.Name = "pdescription";
            this.pdescription.Size = new System.Drawing.Size(295, 27);
            this.pdescription.TabIndex = 19;
            this.pdescription.Text = "Payment Description";
            this.pdescription.TextChanged += new System.EventHandler(this.pdescription_TextChanged);
            this.pdescription.Enter += new System.EventHandler(this.pdescription_Enter);
            this.pdescription.Leave += new System.EventHandler(this.pdescription_Leave);
            // 
            // transc_id
            // 
            this.transc_id.AccessibleName = "";
            this.transc_id.BackColor = System.Drawing.Color.WhiteSmoke;
            this.transc_id.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.transc_id.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tableBindingSource, "transac_id", true));
            this.transc_id.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.transc_id.ForeColor = System.Drawing.Color.DimGray;
            this.transc_id.Location = new System.Drawing.Point(12, 236);
            this.transc_id.Name = "transc_id";
            this.transc_id.Size = new System.Drawing.Size(204, 27);
            this.transc_id.TabIndex = 20;
            this.transc_id.Text = "Transaction ID";
            this.transc_id.TextChanged += new System.EventHandler(this.transc_id_TextChanged);
            this.transc_id.Enter += new System.EventHandler(this.transc_id_Enter);
            this.transc_id.Leave += new System.EventHandler(this.transc_id_Leave);
            // 
            // amount
            // 
            this.amount.AccessibleName = "";
            this.amount.BackColor = System.Drawing.Color.WhiteSmoke;
            this.amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.amount.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tableBindingSource, "amount", true));
            this.amount.Font = new System.Drawing.Font("Segoe UI Semibold", 11F, System.Drawing.FontStyle.Bold);
            this.amount.ForeColor = System.Drawing.Color.Black;
            this.amount.Location = new System.Drawing.Point(256, 236);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(235, 27);
            this.amount.TabIndex = 21;
            this.amount.Text = "000";
            this.amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.amount.TextChanged += new System.EventHandler(this.amount_TextChanged);
            this.amount.Enter += new System.EventHandler(this.amount_Enter);
            this.amount.Leave += new System.EventHandler(this.amount_Leave);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(311, 295);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(169, 34);
            this.button2.TabIndex = 22;
            this.button2.Text = "Add Income Transaction ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(435, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 32;
            this.button1.Text = "close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // churchDatabaseDataSetBindingSource
            // 
            this.churchDatabaseDataSetBindingSource.DataSource = this.church_DatabaseDataSet;
            this.churchDatabaseDataSetBindingSource.Position = 0;
            // 
            // cmboAccount
            // 
            this.cmboAccount.BackColor = System.Drawing.Color.White;
            this.cmboAccount.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tableBindingSource, "account", true));
            this.cmboAccount.Font = new System.Drawing.Font("Segoe UI Semibold", 9.25F, System.Drawing.FontStyle.Bold);
            this.cmboAccount.ForeColor = System.Drawing.Color.DarkGray;
            this.cmboAccount.FormattingEnabled = true;
            this.cmboAccount.Items.AddRange(new object[] {
            "All Accounts",
            "Cash"});
            this.cmboAccount.Location = new System.Drawing.Point(12, 172);
            this.cmboAccount.Name = "cmboAccount";
            this.cmboAccount.Size = new System.Drawing.Size(204, 23);
            this.cmboAccount.TabIndex = 33;
            this.cmboAccount.Text = "Cash";
            this.cmboAccount.SelectedIndexChanged += new System.EventHandler(this.cmboAccount_SelectedIndexChanged_1);
            // 
            // cmboCategory
            // 
            this.cmboCategory.BackColor = System.Drawing.Color.White;
            this.cmboCategory.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.tableBindingSource, "category", true));
            this.cmboCategory.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmboCategory.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.cmboCategory.FormattingEnabled = true;
            this.cmboCategory.Items.AddRange(new object[] {
            "Offerings",
            "Tithes",
            "Pleges"});
            this.cmboCategory.Location = new System.Drawing.Point(256, 172);
            this.cmboCategory.Name = "cmboCategory";
            this.cmboCategory.Size = new System.Drawing.Size(196, 23);
            this.cmboCategory.TabIndex = 34;
            this.cmboCategory.Text = "Offering";
            this.cmboCategory.SelectedIndexChanged += new System.EventHandler(this.cmboCategory_SelectedIndexChanged);
            // 
            // AddIncome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(522, 408);
            this.Controls.Add(this.cmboCategory);
            this.Controls.Add(this.cmboAccount);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.amount);
            this.Controls.Add(this.transc_id);
            this.Controls.Add(this.pdescription);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pfrom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddIncome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = " ";
            this.Load += new System.EventHandler(this.AddIncome_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.church_DatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.churchDatabaseDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox pfrom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox pdescription;
        private System.Windows.Forms.TextBox transc_id;
        private System.Windows.Forms.TextBox amount;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private Church_DatabaseDataSet church_DatabaseDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private Church_DatabaseDataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private System.Windows.Forms.BindingSource churchDatabaseDataSetBindingSource;
        private System.Windows.Forms.ComboBox cmboAccount;
        private System.Windows.Forms.ComboBox cmboCategory;
    }
}