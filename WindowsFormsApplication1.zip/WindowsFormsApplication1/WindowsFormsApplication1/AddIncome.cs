﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class AddIncome : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\USER\Documents\Church Database.mdf;Integrated Security=True;Connect Timeout=30");
        public AddIncome()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private Form2 tabPage;

        public AddIncome(Form2 tabPage)
        {
            InitializeComponent();
            this.tabPage = tabPage;
        }


        private void AddARow(DataTable table)
        {
            // Use the NewRow method to create a DataRow with 
            // the table's schema.
            DataRow newRow = table.NewRow();

            // Add the row to the rows collection.
            table.Rows.Add(newRow);
        }


        private void button2_Click(object sender, EventArgs e)
        {

           // tabPage.dataGridView2.Columns.Add("transc_id", "");
            //tabPage.dataGridView2.Columns.Add("pfrom", "");
            //tabPage.dataGridView2.Columns.Add("pdescription", "");
            //tabPage.dataGridView2.Columns.Add("category", "");
            //tabPage.dataGridView2.Columns.Add("account", "");
            //tabPage.dataGridView2.Columns.Add("amount", "");

            //object[] newRow = new object[] { "1", "Product 1", "1000", DateTime.Now.ToString() };
            //tabPage.dataGridView2.Rows.Add(newRow);



        

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO [Table] values ('" + transc_id.Text + "', '" + pfrom.Text + "','" + pdescription.Text + "','" + cmboCategory.SelectedValue + "','" + cmboAccount.SelectedValue + "','" +
                amount.Text + "')";

             


               
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The data is recorded has been inserted");
            
            }

            catch (Exception ex)

            {
                MessageBox.Show(ex.Message);
            }



           


        }




        private void AddIncome_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'church_DatabaseDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.church_DatabaseDataSet.Table);

        }

        private void cmboAccount_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void transc_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmboAccount_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void pdescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void pfrom_TextChanged(object sender, EventArgs e)
        {

        }

        private void pfrom_Enter(object sender, EventArgs e)
        {
            if (pfrom.Text == " Payment From")
            {
                pfrom.Text = "";

                pfrom.ForeColor = Color.Black;
            }
        }

        private void pfrom_Leave(object sender, EventArgs e)
        {
            if (pfrom.Text == "")
            {
                pfrom.Text = "Payment From";

                pfrom.ForeColor = Color.Silver;
            }


        }

        private void pdescription_Enter(object sender, EventArgs e)
        {

            if (pfrom.Text == "Payment Description")
            {
                pfrom.Text = "";

                pfrom.ForeColor = Color.Black;
            }

        }

        private void pdescription_Leave(object sender, EventArgs e)
        {

            if (pfrom.Text == "")
            {
                pfrom.Text = "Payment Description";

                pfrom.ForeColor = Color.Silver;
            }


        }

        private void transc_id_Enter(object sender, EventArgs e)
        {


            if (pfrom.Text == "Transaction ID")
            {
                pfrom.Text = "";

                pfrom.ForeColor = Color.Black;
            }
        }

        private void transc_id_Leave(object sender, EventArgs e)
        {
            if (pfrom.Text == "")
            {
                pfrom.Text = "Transaction ID";

                pfrom.ForeColor = Color.Silver;
            }


        }

        private void amount_TextChanged(object sender, EventArgs e)
        {

        }

        private void amount_Enter(object sender, EventArgs e)
        {
            if (pfrom.Text == "000")
            {
                pfrom.Text = "";

                pfrom.ForeColor = Color.Black;
            }



        }

        private void amount_Leave(object sender, EventArgs e)
        {
            if (pfrom.Text == "")
            {
                pfrom.Text = "000 ";

                pfrom.ForeColor = Color.Silver;
            }



        }
    }
}
